<?php
if (!$sesobj->isassign('user')){
   //	header("location:index.php");
}

$submit=getVariable("donar_reg");

if(isset($submit))
{
	$donar_name=getVariable("donar_name");
    $area=getVariable("area");
    $donar_ph=getVariable("donar_ph");
    $f_type=getVariable("f_type");
    $f_for=getVariable("f_for");
    $f_count=getVariable("f_count");
    $transport=getVariable("transport");
	$donar_msg=getVariable("donar_msg");

 $q="insert into donar(donar_name,area,donar_ph,f_type,f_for,f_count,transport,donar_msg,getby) values ('".$donar_name."','".$area."','".$donar_ph."','".$f_type."','".$f_for."','".$f_count."','".$transport."','".$donar_msg."','')";
	$q= $sqlobj->query($q);

$username="ppvtechnology";
$password="9095671496";
$message='From '.$area.' we have a '.$f_type.' '.$f_for.' food for '.$f_count.' people'.' For Contact : '.$donar_ph;
$sender="TSVPSC";

$q="SELECT * FROM orphan WHERE area='$area'";
$orphan_list= $sqlobj->getlist($q);

foreach ($orphan_list as $key=>$val)
			{

			    $mobile_number = $orphan_list[$key]['orphan_ph'] ;

$url="http://login.bulksmsgateway.in/sendmessage.php?user=".urlencode($username)."&password=".urlencode($password)."&mobile=".urlencode($mobile_number)."&message=".urlencode($message)."&sender=".urlencode($sender)."&type=".urlencode('3');

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$curl_scraped_page = curl_exec($ch);

            }

curl_close($ch);

	header("Location:login.php");
	exit;
}

if(!$userobj->tmp_filecheck($page)) {
	echo _TMPFILE_ERROR ;
} else {
	include(_PATH_TEMPLATE."common.php");
}
?>