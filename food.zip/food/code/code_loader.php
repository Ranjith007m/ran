<?PHP
	/* Load Class Files */
	require_once(_PATH_INCLUDE."session.php");
	require_once(_PATH_INCLUDE."mysql.php");
	require_once(_PATH_INCLUDE."db.php");
	require_once(_PATH_INCLUDE."userfunctions.php");
	require_once(_PATH_INCLUDE."paging.php");
	//require_once(_PATH_INCLUDE."fckeditor/fckeditor.php");
	require_once(_PATH_INCLUDE."image_resize.php");
	
	require_once(_PATH_INCLUDE."mail.php");
	/* Create database object */
	$sqlobj=new dbconn(_HOSTNAME, _USERNAME, _PASSWORD, _DATABASE);
	
	/* Create session object */
	$sesobj=new SESSION_MANAGEMENT();	

	/** Create UserFunctions object */
	$userobj=new UserFunctions();

	/** Create Pageing Object */
	$pageobj=new Paging('5');

	/* create mail object */
	$mailobj=new Mail();
	
	/* create image resize object */
	$imageobj=new resize_image();

	set_time_limit (3600);

	function getVariable($key, $defval=NULL)
	{
		if(isset($_POST[$key]))
			return $_POST[$key];
		else if(isset($_GET[$key]))
			return $_GET[$key];
		else
			return $defval;
	}
	require_once(_PATH_INCLUDE."message.php");
?>
