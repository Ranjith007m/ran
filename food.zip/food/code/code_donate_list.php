<?php
global $sqlobj,$sesobj,$userobj,$imageobj;

if (!$sesobj->isassign('orphan_name'))
{
	header("location:index.php");
}


if(getVariable('submit') && getVariable('submit')!='')
{
$submit='';
$submit = getVariable('submit');
}

switch($submit)
{

case 'edit_task': edit_task();
break;
case 'delete': delete();
break;

}


function edit_task()
{
	$id=base64_decode(base64_decode(getVariable('id')));
	global $sqlobj,$sesobj,$userobj,$imageobj;

        $getby=$sesobj->get('orphan_name');
		$q="update donar set getby='".$getby."' where id='".$id."'";
		$q = $sqlobj->query($q);
	
	($q) ?	$sesobj->assign('msg','c-5') : $sesobj->assign('msg','e-6');
	header("Location:donate_list.php");
	exit;
}

 function delete()
 {
      global $sqlobj,$sesobj;
	 $id=getVariable('delete_id');
	 $id=base64_decode(base64_decode($id));
     $sqlobj->delete_rows(donar,"id='$id'");

	 $sesobj->assign('msg','c-8');
		   header("Location:donate_list.php");
		   exit;
 }

    $q="select * from donar order by id desc";
	$donar_res = $sqlobj-> getlist($q);


if(!$userobj->tmp_filecheck($page)) 
{
	echo _TMPFILE_ERROR ;
} 
else 
{
	include(_PATH_TEMPLATE."common.php");
}
?>