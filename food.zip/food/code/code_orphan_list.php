<?php
if (!$sesobj->isassign('user')){
	//header("location:index.php");
}
 global $sqlobj,$sesobj;

 $q="select * from orphan order by id Asc";
 $search_res= $sqlobj->getlist($q);

 if(getVariable('task')=='delete')
 {
      global $sqlobj,$sesobj;
	 $id=getVariable('delete_id');
	 $id=base64_decode(base64_decode($id));
     $sqlobj->delete_rows(orphan,"id='$id'");

	 $sesobj->assign('msg','c-8');
		   header("Location:orphan_list.php");
		   exit;
 }

if(!$userobj->tmp_filecheck($page)) {
	echo _TMPFILE_ERROR ;
} else {
	include(_PATH_TEMPLATE."common.php");
}
?>
