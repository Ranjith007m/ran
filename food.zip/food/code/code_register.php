<?php
global $sqlobj,$sesobj,$userobj,$imageobj;

$orphan_reg=getVariable("orphan_reg");
if(isset($orphan_reg))
{
	$orphan_name=getVariable("orphan_name");
    $orphan_ph=getVariable("orphan_ph");
    $orphan_email=getVariable("orphan_email");
    $password=getVariable("password");
	$orphan_person=getVariable("orphan_person");
    $orphan_web=getVariable("orphan_web");
    $area=getVariable("area");
    $orphan_count=getVariable("orphan_count");
    $orphan_cost=getVariable("orphan_cost");
	$orphan_msg=getVariable("orphan_msg");

	$q="SELECT * FROM orphan where orphan_ph='$orphan_ph'";
	$emp_list= $sqlobj->getlist($q);
	if(!empty($emp_list))
	{
		$message="Mobile No Already exist!";

	}

	else{
	    $q="insert into orphan(orphan_name,orphan_ph,orphan_email,password,orphan_person,orphan_web,area,orphan_count,orphan_cost,orphan_msg) values ('".$orphan_name."','".$orphan_ph."','".$orphan_email."','".$password."','".$orphan_person."','".$orphan_web."','".$area."','".$orphan_count."','".$orphan_cost."','".$orphan_msg."')";
	$q= $sqlobj->query($q);

	header("Location:orphan_list.php");
	exit;}
}

if(isset($update) && $update='update')
{
    $name=getVariable("name");
    $phone=getVariable("phone");
    $emp_id=getVariable("emp_id");
	$address=getVariable("address");
	$proof=getVariable("proof");
    $doj=getVariable("doj");
	$gender=getVariable("gender");
	$bank=getVariable("bank");
    $q="update employee set name='".$name."',phone='".$phone."',address='".$address."',proof='".$proof."',doj='".$doj."',gender='".$gender."',bank='".$bank."' where emp_id='".$emp_id."'";
	$q = $sqlobj->query($q);
}

if(getVariable('id')!="")
{

    $id=base64_decode(base64_decode(getVariable('id')));
	$q="SELECT * FROM `employee` where `employee`.`id`='$id'";
	$task_res = $sqlobj-> getlist($q);

}
?>


<?php if(!$userobj->tmp_filecheck($page)) {
	echo _TMPFILE_ERROR;
} else {
	include(_PATH_TEMPLATE."common.php");
}
?>