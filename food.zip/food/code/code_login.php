<?php
if (!$sesobj->isassign('user')){
	//header("location:index.php");
}
 global $sqlobj,$sesobj;

$admin_login=getVariable("admin_login");

if(isset($admin_login))
{
	if(getVariable("username")=='admin' && getVariable("password")=='admin123')
    {
    	$sesobj->assign('orphan_name','Admin');
    header("Location:donate_list.php");
	exit;
    }
    else {
        $message="Invalid Username / Password !";
    }
}

$orphan_login=getVariable("orphan_login");

if(isset($orphan_login))
{
$o_email=getVariable("username");
$password=getVariable("password");
$q="select * from orphan where orphan_email='$o_email'";
$temp= $sqlobj->getlist($q);
if($temp[0]['password']==$password)
		{
			$sesobj->assign('orphan_name',$temp[0]['orphan_name']);
			header("Location:donate_list.php");
			exit;
		}
		else {
		$message1="Invalid Username / Password Please try again!";
			}
}

if(!$userobj->tmp_filecheck($page)) {
	echo _TMPFILE_ERROR ;
} else {
	include(_PATH_TEMPLATE."common.php");
}
?>
