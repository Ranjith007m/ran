<?php
if (!$sesobj->isassign('user')){
	header("location:index.php");
}
 global $sqlobj,$sesobj;


if(getVariable('search') && getVariable('search')!='')
{
	global $sqlobj,$sesobj;

	$emp_id=getVariable('emp_id');
    $cus_ph=getVariable('cus_ph');
	$from_date=getVariable('from_date');
    $to_date=getVariable('to_date');
    if($emp_id!=''){
        $q="select * from service where emp_id='$emp_id' order by b_date desc";
	    $search_res= $sqlobj->getlist($q);
        $q="select sum(amount) from service where emp_id='$emp_id'";
	    $amount_res= $sqlobj->getlist($q);
        $q="select * from employee where emp_id='$emp_id'";
	    $emp_res= $sqlobj->getlist($q);

    }
    if($from_date!='' && $to_date!=''){
         $q="select * from service where emp_id='$emp_id' and b_date>='$from_date' and b_date<='$to_date' order by b_date desc";
	     $search_res= $sqlobj->getlist($q);
         $q="select sum(amount) from service where emp_id='$emp_id' and b_date>='$from_date' and b_date<='$to_date' order by b_date desc";
	    $amount_res= $sqlobj->getlist($q);

    }
    if($emp_id!='' && $cus_ph!=''){
        $q="select * from service where emp_id='$emp_id' and cus_ph='$cus_ph' order by b_date desc";
	    $search_res= $sqlobj->getlist($q);
        $q="select sum(amount) from service where emp_id='$emp_id' and cus_ph='$cus_ph' order by b_date desc";
	    $amount_res= $sqlobj->getlist($q);
        $q="select * from employee where emp_id='$emp_id'";
	    $emp_res= $sqlobj->getlist($q);


    }
    if($emp_id!='' && $cus_ph!='' && $from_date!='' && $to_date!=''){
        $q="select * from service where emp_id='$emp_id' and cus_ph='$cus_ph' and b_date>='$from_date' and b_date<='$to_date' order by b_date desc";
	    $search_res= $sqlobj->getlist($q);
        $q="select sum(amount) from service where emp_id='$emp_id' and cus_ph='$cus_ph' and b_date>='$from_date' and b_date<='$to_date' order by b_date desc";
	    $amount_res= $sqlobj->getlist($q);
        $q="select * from employee where emp_id='$emp_id'";
	    $emp_res= $sqlobj->getlist($q);

    }


}



if(!$userobj->tmp_filecheck($page)) {
	echo _TMPFILE_ERROR ;
} else {
	include(_PATH_TEMPLATE."common.php");
}
?>
