<?php
if(!$userobj->tmp_filecheck($page)) {
	echo _TMPFILE_ERROR;
} else {
	include(_PATH_TEMPLATE."common.php");
    include(_PATH_CODE."script.php");
}
?>