<?php

$session_message=$sesobj->get('msg');

if($session_message=="e-1")

	$message="Your old Password is incorrect";

if($session_message=="c-2")

	$message="Password changed Successfully";

if($session_message=="c-3")

	$message="Customer added successfully";

if($session_message=="e-4")

	$message="Error in adding Customer";

if($session_message=="c-5")

	$message="Customer detail edited Successfully";

if($session_message=="e-6")

	$message="Error in editing Customer detail";

if($session_message=="e-7")

	$message="Please select a Section from the list to delete";

if($session_message=="c-8")

	$message="Customer deleted Successfully";

if($session_message=="c-9")

	$message="Tariff added Successfully";

if($session_message=="e-10")

	$message="Error in addinging tariff";

if($session_message=="c-11")

	$message="Tariff edited Successfully";

if($session_message=="e-12")

	$message="Error in editing tariff";

if($session_message=="e-13")

	$message="Tariff deleted Successfully";

if($session_message=="e-14")

	$message="Please select a Customer For Bill";

if($session_message=="c-15")

	$message="Category added Successfully";

if($session_message=="e-16")

	$message="Error in adding Category";

if($session_message=="e-17")

	$message="Please select a Category from the list to delete";

if($session_message=="c-18")

	$message="Employee deleted Successfully";

if($session_message=="e-19")

	$message="Please select a Category from the list to publish";

if($session_message=="c-20")

	$message="Category Published Successfully";

if($session_message=="e-21")

	$message="Error in publishing Category";

if($session_message=="e-22")

	$message="Please select a Category from the list to unpublish";

if($session_message=="c-23")

	$message="Category Unpublished Successfully";

if($session_message=="e-24")

	$message="Error in Unpublished Category";

if($session_message=="c-25")

	$message="Category edited Successfully";

if($session_message=="e-26")

	$message="Error in editing Category";

if($session_message=="c-27")

	$message="Jobs added Successfully";

if($session_message=="e-28")

	$message="Error in adding Jobs";

if($session_message=="c-29")

	$message="Jobs edited Successfully";

if($session_message=="e-30")

	$message="Error in editing Jobs";

if($session_message=="e-31")

	$message="Please select a Jobs from the list to delete";

if($session_message=="c-32")

	$message="jobs deleted Successfully";

if($session_message=="e-33")

	$message="Please select a Jobs from the list to publish";

if($session_message=="c-34")

	$message="Jobs Published Successfully";

if($session_message=="e-35")

	$message="Error in publishing Jobs";

if($session_message=="e-36")

	$message="Please select a Jobs from the list to unpublish";

if($session_message=="c-37")

	$message="Jobs Unpublished Successfully";

if($session_message=="e-38")

	$message="Error in Unpublished Jobs";

if($session_message=="e-39")

	$message="Error in file type";

if($session_message=="e-40")

	$message="Email already present";

if($session_message=="e-41")

	$message="Invalid E-mail or Password";

if($session_message=="e-42")

	$message="Email already present";

if($session_message=="e-43")

	$message="You must accept the terms and condition";

if($session_message=="e-44")

	$message="Invalid E-mail";

if($session_message=="e-45")

	$message="Select a qualification";

if($session_message=="e-46")

	$message="Invalid email or password";

if($session_message=="c-47")

	$message="Profile Added Successfully";

if($session_message=="c-48")

	$message="Profile Edited Successfully";

if($session_message=="c-49")

	$message="Project Posted Successfully";

if($session_message=="e-50")

	$message="Please select a User from the list to publish";

if($session_message=="c-51")

	$message="User Published Successfully";

if($session_message=="e-52")

	$message="Error in publishing User";

if($session_message=="c-53")

	$message="User Unpublished Successfully";

if($session_message=="e-54")

	$message="Error in Unpublishing User";

if($session_message=="e-55")

	$message="Please select a User from the list to unpublish";

if($session_message=="e-56")

	$message="Your Account not get Activated";

if($session_message=="e-57")

	$message="Please select a User from the list to delete";

if($session_message=="c-58")

	$message="User deleted Successfully";

if($session_message=="e-59")

	$message="Please select a Project from the list to delete";

if($session_message=="c-60")

	$message="Project deleted Successfully";

if($session_message=="e-61")

	$message="Please select a Project from the list to publish";

if($session_message=="c-62")

	$message="Project Published Successfully";

if($session_message=="e-63")

	$message="Error in publishing Project";

if($session_message=="e-64")

	$message="Please select a Project from the list to unpublish";

if($session_message=="c-65")

	$message="Project Unpublished Successfully";

if($session_message=="e-66")

	$message="Error in Unpublishing Project";

if($session_message=="c-67")

	$message="Please check your email, to change your password";

if($session_message=="e-68")

	$message="Your password reset request failed because a User with the e-mail address could not be found..";

if($session_message=="c-69")

	$message="Password changed successfully";

if($session_message=="e-70")

	$message="Invalid User";

if($session_message=="c-71")

	$message="Page added Successfully";

if($session_message=="e-72")

	$message="Error in adding Page";

if($session_message=="c-73")

	$message="Page edited Successfully";

if($session_message=="e-74")

	$message="Error in editing Page";

if($session_message=="e-75")

	$message="Please select a Page from the list to publish";

if($session_message=="c-76")

	$message="Page Published Successfully";

if($session_message=="e-77")

	$message="Error in publishing Page";

if($session_message=="e-78")

	$message="Please select a Page from the list to unpublish";

if($session_message=="c-79")

	$message="Page Unpublished Successfully";

if($session_message=="e-80")

	$message="Error in Unpublishing Page";

if($session_message=="c-81")

	$message="Enquiry send successfully";

if($session_message=="e-82")

	$message="Upload only jpg,gif,png files";

if($session_message=="e-83")

	$message="Invalid image size";

if($session_message=="c-84")

	$message="Partner added Successfully";

if($session_message=="e-85")

	$message="Error in adding Partner";

if($session_message=="e-86")

	$message="Please select a Partner from the list to delete";

if($session_message=="c-87")

	$message="Partner deleted Successfully";

if($session_message=="e-88")

	$message="Please select a Project from the list to publish";

if($session_message=="c-89")

	$message="Partner Published Successfully";

if($session_message=="e-90")

	$message="Error in publishing Partner";

if($session_message=="e-91")

	$message="Please select a Partner from the list to unpublish";

if($session_message=="c-92")

	$message="Partner Unpublished Successfully";

if($session_message=="e-93")

	$message="Error in Unpublishing Partner";

if($session_message=="c-94")

	$message="Partner edited Successfully";

if($session_message=="e-95")

	$message="Error in editing Partner";

if($session_message=="e-96")

	$message="Please select a News from the list to delete";

if($session_message=="c-97")

	$message="News deleted Successfully";

if($session_message=="e-98")

	$message="Please select a News from the list to publish";

if($session_message=="c-99")

	$message="News Published Successfully";

if($session_message=="e-100")

	$message="Error in publishing News";

if($session_message=="e-101")

	$message="Please select a News from the list to unpublish";

if($session_message=="c-102")

	$message="News Unpublished Successfully";

if($session_message=="e-103")

	$message="Error in Unpublishing News";

if($session_message=="c-104")

	$message="News added Successfully";

if($session_message=="e-105")

	$message="Error in adding News";

if($session_message=="c-106")

	$message="News edited Successfully";

if($session_message=="e-107")

	$message="Error in editing News";

if($session_message=="c-108")

	$message="NGO added Successfully";

if($session_message=="e-109")

	$message="Error in adding NGO";

if($session_message=="c-109")

$message="Project added successfully";

if($session_message=="e-110")

$message="Error in adding project";

if($session_message=="c-110")

$message="Project edited successfully";

if($session_message=="c-111")

$message="E-mail edited successfully";

if($session_message=="e-111")

$message="Error editing E-mail";

if($session_message=="c-112")

$message="Specifications edited successfully";

if($session_message=="e-112")

$message="Error editing Specifications";

if($session_message=="c-113")

$message="Specifications added successfully";

if($session_message=="e-113")

$message="Error adding Specifications";

if($session_message=="c-114")

$message="Floor Plan added successfully";

if($session_message=="e-114")

$message="Error adding Floor Plan";

if($session_message=="c-115")

$message="Location added successfully";

if($session_message=="e-115")

$message="Error adding location";







?>