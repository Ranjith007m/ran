<?PHP

class UserFunctions

{

	function filecheck($filename)

	{

		return is_file($filename);

	}

	function tmp_filecheck($filename)

	{

		return $this->filecheck(_PATH_TEMPLATE.$filename.".php");

	}

	function code_filecheck($filename)

	{

		return $this->filecheck(_PATH_CODE.$filename.".php");

	}

	function splitword($word,$offset)

	{

		$temp = "";

		if($temp1 = explode(" ",$word))

		{

			for($i=0;$i<$offset;$i++)

			{

				$temp .= " ".$temp1[$i];

			}

			if(isset ($temp1[$offset+1]))	

			{

				$temp .= "... ";

			}

		}

		return $temp;

	}

	function formcheck($fields,$alretmsg)

	{

		$msg = "";

		for($i=0;$i<count($fields);$i++) {

			if($this->getVariableFromRequest($fields[$i])==""){

				$msg = "Please fill the ".$alretmsg[$i].".";

				break;

			}

		}

		return $msg;

	}

	function print_rr($array)

	{

	echo '<pre>';

	print_r($array);

	echo '</pre>';

	}

	

	function is_valid_email($email) {

	$result = TRUE;

	if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $email)) {

	$result = FALSE;

	}

	return $result;

	}

	

	function image_validate($image_type)

	{

		$type=explode("/",$image_type);

		if($type[1]!="jpeg"  && $type[1]!="gif" && $type[1]!="png" && $type[1]!="pjpeg"  )

			return false;

		else

			return true;

	}



	function generatePassword($length=9, $strength=0) {

	$vowels = 'aeuy';

	$consonants = 'bdghjmnpqrstvz';

	if ($strength & 1) {

		$consonants .= 'BDGHJLMNPQRSTVWXZ';

	}

	if ($strength & 2) {

		$vowels .= "AEUY";

	}

	if ($strength & 4) {

		$consonants .= '23456789';

	}

	if ($strength & 8) {

		$consonants .= '@#$%';

	}

 

	$password = '';

	$alt = time() % 2;

	for ($i = 0; $i < $length; $i++) {

		if ($alt == 1) {

			$password .= $consonants[(rand() % strlen($consonants))];

			$alt = 0;

		} else {

			$password .= $vowels[(rand() % strlen($vowels))];

			$alt = 1;

		}

	}

	return $password;

	}

	

	function compareDates($date1,$date2) {

	$date1_array = explode("-",$date1);

	$date2_array = explode("-",$date2);

	$timestamp1 =

	mktime(0,0,0,$date1_array[1],$date1_array[2],$date1_array[0]);

	$timestamp2 =

	mktime(0,0,0,$date2_array[1],$date2_array[2],$date2_array[0]);

	if ($timestamp1>$timestamp2) {

	return 0;

	} else if ($timestamp1<$timestamp2) {

	return 0;

	} else {

	return 1;

	}

	} 

	



function dateDiff($dformat, $endDate, $beginDate)

{

$date_parts1=explode($dformat, $beginDate);

$date_parts2=explode($dformat, $endDate);

$start_date=gregoriantojd($date_parts1[0], $date_parts1[1], $date_parts1[2]);

$end_date=gregoriantojd($date_parts2[0], $date_parts2[1], $date_parts2[2]);

return $end_date - $start_date;

}

	

	function getDates($start,$end)

	{

	global $userobj;

	

	$init_date = strtotime($start);

	$dst_date = strtotime($end);

	

	$offset = $dst_date-$init_date;

	

	$dates = floor($offset/60/60/24) + 1;

	

	for ($i = 0; $i < $dates; $i++)

	{

	$newdate[] = date("Y-m-d", mktime(12,0,0,date("m", strtotime($start)),(date("d", strtotime($start)) + $i), date("Y", strtotime($start))));

	}

	return $newdate;

	}

	

function getDaysInBetween($start, $end) {

// Vars

$day = 86400; // Day in seconds

$format = 'Y-m-d'; // Output format (see PHP date funciton)

$sTime = strtotime($start); // Start as time

$eTime = strtotime($end); // End as time

$numDays = round(($eTime - $sTime) / $day) + 1;

$days = array();



// Get days

for ($d = 0; $d < $numDays; $d++) {

$days[] = date($format, ($sTime + ($d * $day)));

}



// Return days

return $days;

} 



}

?>