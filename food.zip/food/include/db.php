<?PHP

include_once(_PATH_INCLUDE."abstract_table.php");

class dbconn extends abstract_table {

	function dbconn($host, $username, $password, $dbname) {

		$this->openDB($host, $username, $password, $dbname);

	}

	######## Add new SQL FUNCTIONS ##################

	function adminlogincheck($username, $password) {

		$adminlist = $this->getdatalist("*", "adminlogin", "adminid = '".$username."' and password ='".$password."'");

		if(count($adminlist)>0) {

			return $adminlist[0];

		} else {

			return false;

		}

	}

	

	######## Add new SQL FUNCTIONS ##################

}

?>