<!-- footer -->
	<div class="footer">
		<div class="container">
			<ul class="social">
				<li><a class="social-facebook" href="#">
						<i class="fa fa-facebook" aria-hidden="true"></i>
						<div class="tooltip"><span>Facebook</span></div>
					</a>
				</li>
				<li><a class="social-twitter" href="#">
					<i class="fa fa-twitter" aria-hidden="true"></i>
					<div class="tooltip"><span>Twitter</span></div>
					</a></li>
				<li><a class="social-google" href="#">
					<i class="fa fa-google-plus" aria-hidden="true"></i>
					<div class="tooltip"><span>Google+</span></div>
					</a></li>
				<li><a class="social-pinterest" href="#">
					<i class="fa fa-pinterest-p" aria-hidden="true"></i>
					<div class="tooltip"><span>Pinterest</span></div>
					</a></li>
				<li><a class="social-instagram" href="#">
					<i class="fa fa-instagram" aria-hidden="true"></i>
					<div class="tooltip"><span>Instagram</span></div>
					</a></li>
			</ul>
			<ul class="main-nav">
				<li><a href="index.html">Home</a><i>|</i></li>
				<li><a href="#about" class="scroll">About Us</a><i>|</i></li>
				<li><a href="#gallery" class="scroll">Gallery</a><i>|</i></li>
				<li><a href="#services" class="scroll">Services</a><i>|</i></li>
				<li><a href="#mail" class="scroll">Mail Us</a></li>
			</ul>
			<div class="copy-right">
				<p>© 2017 Orphanage Home. All rights reserved </p>
			</div>
		</div>
	</div>
<!-- //footer -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!-- for bootstrap working -->
	<script src="js/bootstrap.min.js"></script>
<!-- //for bootstrap working -->
<!-- menu-plugin -->
<script type="text/javascript" src="js/gnmenu.js"></script>
<!-- //menu-plugin -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
				};
			*/

			$().UItoTop({ easingType: 'easeOutQuart' });

			});
	</script>
<!-- //here ends scrolling icon -->