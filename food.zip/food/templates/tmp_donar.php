<br><br><div class="mail" id="mail">
		<div class="container">
			<h3 class="agileinfo_header w3layouts_header">Donator<span>Registration</span></h3>
			<p class="w3_services_para"><span>Here You Can Register As a Volunteer</span></p>
			<div class="w3_agile_services_grids w3_agile_mailwe_grids">
				<form action="" method="post">
					<div class="col-md-6 w3_agile_mail_grid">
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="donar_name" id="input-25" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-25">
								<span class="input__label-content input__label-content--ichiro">Your Name</span>
							</label>
						</span>
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="area" id="input-26" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-26">
								<span class="input__label-content input__label-content--ichiro">Area</span>
							</label>
						</span>
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="donar_ph" id="input-27" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-27">
								<span class="input__label-content input__label-content--ichiro">Your Phone Number</span>
							</label>
						</span>
                        <span class="input input--ichiro">
                            <input class="input__field input__field--ichiro" type="text" name="f_type" id="input-28" placeholder="Veg / Non-Veg" required="" />
							<label class="input__label input__label--ichiro" for="input-28">
								<span class="input__label-content input__label-content--ichiro">Food Type</span>
							</label>
						</span>
                        <span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="f_for" id="input-31" placeholder="Break Fast / Lunch / Dinner" required="" />
							<label class="input__label input__label--ichiro" for="input-31">
								<span class="input__label-content input__label-content--ichiro">Food For</span>
							</label>
						</span>
						<input type="submit" value="Submit" name="donar_reg">
					</div>
					<div class="col-md-6 w3_agile_mail_grid">
                        <span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="f_count" id="input-29" placeholder="Enter Quantity" required="" />
							<label class="input__label input__label--ichiro" for="input-29">
								<span class="input__label-content input__label-content--ichiro">Food Available For</span>
							</label>
						</span>
                        <span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="transport" id="input-30" placeholder="Yes / No" required="" />
							<label class="input__label input__label--ichiro" for="input-30">
								<span class="input__label-content input__label-content--ichiro">Transport Available</span>
							</label>
						</span>
						<textarea  name="donar_msg" placeholder="Your message here..." required=""></textarea>
					</div>
					<div class="clearfix"> </div>
				</form>
			</div>
		</div>
	</div>