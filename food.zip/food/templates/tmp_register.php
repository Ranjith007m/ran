<br><br><div class="mail" id="mail">
		<div class="container">
			<h3 class="agileinfo_header w3layouts_header">Orphanage<span>Registration</span></h3>
			<p class="w3_services_para"><span>Here You Can Register Orphanage Details</span></p>
			<div class="w3_agile_services_grids w3_agile_mailwe_grids">
				<form action="" method="post">
					<div class="col-md-6 w3_agile_mail_grid">
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="orphan_name" id="input-51" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-51">
								<span class="input__label-content input__label-content--ichiro"> Orphanage Name</span>
							</label>
						</span>
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="email" name="orphan_email" id="input-52" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-52">
								<span class="input__label-content input__label-content--ichiro">Orphanage Email</span>
							</label>
						</span>
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="orphan_ph" id="input-53" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-53">
								<span class="input__label-content input__label-content--ichiro">Orphanage Phone Number</span>
							</label>
						</span>
                        <span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="password" id="input-49" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-49">
								<span class="input__label-content input__label-content--ichiro">Password</span>
							</label>
						</span>
                        <span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="orphan_person" id="input-50" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-50">
								<span class="input__label-content input__label-content--ichiro">Contact Person</span>
							</label>
						</span>
                        <span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="orphan_web" id="input-54" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-54">
								<span class="input__label-content input__label-content--ichiro">Website</span>
							</label>
						</span>
						<input type="submit" value="Submit" name="orphan_reg">
					</div>
					<div class="col-md-6 w3_agile_mail_grid">
                    <span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="area" id="input-57" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-57">
								<span class="input__label-content input__label-content--ichiro">Area</span>
							</label>
						</span>
                    <span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="orphan_count" id="input-55" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-55">
								<span class="input__label-content input__label-content--ichiro">No Of Persons</span>
							</label>
						</span>
                    <span class="input input--ichiro">
							<input class="input__field input__field--ichiro" type="text" name="orphan_cost" id="input-56" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-56">
								<span class="input__label-content input__label-content--ichiro">Per day food cost</span>
							</label>
						</span>
						<textarea name="orphan_msg" style="min-height: 220px;" placeholder="Your message here..." required=""></textarea>
					</div>
					<div class="clearfix"> </div>
				</form>
			</div>
		</div>
	</div>