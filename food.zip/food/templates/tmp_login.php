<br><br><div class="mail col-md-6" id="mail">

			<h3 class="agileinfo_header w3layouts_header">ADMIN&nbsp;<span>Login</span></h3>
			<p class="w3_services_para"><span>Here You Can Login As a Admin</span></p>
            <?php if($message!=null) { ?>
				<br><br><p style="color:red; padding:5px 5px 10px 0px; width:100%;" align="center"><b>&nbsp;<?php echo $message; ?></b></p>
			<?php $message='';} ?>
			<div class="w3_agile_services_grids w3_agile_mailwe_grids">
				<form action="" method="post">
					<div class="col-md-12 w3_agile_mail_grid">
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" name="username" type="text" id="input-1" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-1">
								<span class="input__label-content input__label-content--ichiro">User Name</span>
							</label>
						</span>
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" name="password" type="password" id="input-2" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-2">
								<span class="input__label-content input__label-content--ichiro">Password</span>
							</label>
						</span>
						<input type="submit" name="admin_login" value="Submit">
					</div>
					<div class="clearfix"> </div>
				</form>
			</div>

	</div>

<div class="mail col-md-6" id="mail">

			<h3 class="agileinfo_header w3layouts_header">ORPHANAGE&nbsp;<span>Login</span></h3>
			<p class="w3_services_para"><span>Here You Can Login As a Orphanage</span></p>
            <?php if($message1!=null) { ?>
				<br><br><p style="color:red; padding:5px 5px 10px 0px; width:100%;" align="center"><b>&nbsp;<?php echo $message1; ?></b></p>
			<?php $message1='';} ?>
			<div class="w3_agile_services_grids w3_agile_mailwe_grids">
				<form action="" method="post">
					<div class="col-md-12 w3_agile_mail_grid">
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" name="username" type="email" id="input-26" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-26">
								<span class="input__label-content input__label-content--ichiro">Your Email</span>
							</label>
						</span>
						<span class="input input--ichiro">
							<input class="input__field input__field--ichiro" name="password" type="password" id="input-27" placeholder=" " required="" />
							<label class="input__label input__label--ichiro" for="input-27">
								<span class="input__label-content input__label-content--ichiro">Password</span>
							</label>
						</span>
						<input type="submit" name="orphan_login" value="Submit">
					</div>

					<div class="clearfix"> </div>
				</form>
			</div>

	</div>

    	<div class="clearfix"> </div>