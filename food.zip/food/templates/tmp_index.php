<!-- banner-bottom -->
	<div class="banner-bottom" id="about">
		<div class="container">
			<h3>real <span>charity</span> is giving from the heart without taking credit</h3>
			<p class="para_w3ls">Nulla imperdiet lorem eu pretium vestibulum. Duis aliquet lacinia ullamcorper.
				Proin imperdiet dui et magna posuere imperdiet. Vivamus tempus ut dolor vel pulvinar.
				Quisque mattis orci quis porttitor posuere. Ut bibendum tincidunt elit eget mattis.</p>
			<div class='film_roll_container'>
				<div id='film_roll_2'>
					<div id='fr2_0'><img src="images/1.jpg" alt=" " class="img-responsive" /></div>
					<div id='fr2_1'><img src="images/2.jpg" alt=" " class="img-responsive" /></div>
					<div id='fr2_2'><img src="images/3.jpg" alt=" " class="img-responsive" /></div>
					<div id='fr2_3'><img src="images/4.jpg" alt=" " class="img-responsive" /></div>
					<div id='fr2_4'><img src="images/5.jpg" alt=" " class="img-responsive" /></div>
				</div>
				<a href='#' class='btn btn-primary w3l_btn' id='film_roll_2_left'><i class="fa fa-long-arrow-left" aria-hidden="true"></i></a>
				<a href='#' class='btn btn-primary w3l_btn' id='film_roll_2_right'><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
			</div>
			<div class="w3_banner_bottom_service">
				<div class="col-md-4 w3_banner_bottom_service1">
					<div class="col-xs-4 w3layouts_banner_bottom_servicel">
						<div class="agile-hvr-icon-pulse-shrink agileits_w3layouts_thumb">
						</div>
					</div>
					<div class="col-xs-8 w3layouts_banner_bottom_servicer">
						<h4>become a volunteer</h4>
						<p>Quisque mattis orci quis porttitor posuere ut bibendum
							tincidunt</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-4 w3_banner_bottom_service1">
					<div class="col-xs-4 w3layouts_banner_bottom_servicel">
						<div class="agile-hvr-icon-pulse-shrink agileits_w3layouts_gift">
						</div>
					</div>
					<div class="col-xs-8 w3layouts_banner_bottom_servicer">
						<h4>make a gift</h4>
						<p>Quisque mattis orci quis porttitor posuere ut bibendum
							tincidunt</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-4 w3_banner_bottom_service1">
					<div class="col-xs-4 w3layouts_banner_bottom_servicel">
						<div class="agile-hvr-icon-pulse-shrink agileits_w3layouts_heart">
						</div>
					</div>
					<div class="col-xs-8 w3layouts_banner_bottom_servicer">
						<h4>give a scholarship</h4>
						<p>Quisque mattis orci quis porttitor posuere ut bibendum
							tincidunt</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //banner-bottom -->
<!-- carousal-plugin -->
<script src="js/jquery.film_roll.js"></script>
<script src="js/index.js"></script>
<!-- //carousal-plugin -->

<!-- services -->
	<div class="services" id="services">
		<div class="container">
			<h3 class="agileinfo_header w3layouts_header">what <span>services</span> we provide</h3>
			<p class="w3_services_para"><span>Nullam volutpat nisi leo eu dictum</span></p>
			<div class="w3_agile_services_grids">
				<div class="col-md-3 w3_agile_services_grid">
					<div class="ih-item circle effect1 agile_services_grid">
						<div class="spinner"></div>
						<div class="img"><img src="images/1.png" alt=" " class="img-responsive" /></div>
					</div>
					<fieldset>
						<legend>Shelter for children's</legend>
							Donec ullamcorper ipsum quis turpis scelerisque, efficitur scelerisque urna pharetra.
					</fieldset>
				</div>
				<div class="col-md-3 w3_agile_services_grid">
					<div class="ih-item circle effect1 agile_services_grid">
						<div class="spinner"></div>
						<div class="img"><img src="images/4.png" alt=" " class="img-responsive" /></div>
					</div>
					<fieldset>
						<legend>happiness for child</legend>
							Donec ullamcorper ipsum quis turpis scelerisque, efficitur scelerisque urna pharetra.
					</fieldset>
				</div>
				<div class="col-md-3 w3_agile_services_grid">
					<div class="ih-item circle effect1 agile_services_grid">
						<div class="spinner"></div>
						<div class="img"><img src="images/2.png" alt=" " class="img-responsive" /></div>
					</div>
					<fieldset>
						<legend>Sponsor a child today</legend>
							Donec ullamcorper ipsum quis turpis scelerisque, efficitur scelerisque urna pharetra.
					</fieldset>
				</div>
				<div class="col-md-3 w3_agile_services_grid">
					<div class="ih-item circle effect1 agile_services_grid">
						<div class="spinner"></div>
						<div class="img"><img src="images/3.png" alt=" " class="img-responsive" /></div>
					</div>
					<fieldset>
						<legend>education for children's</legend>
							Donec ullamcorper ipsum quis turpis scelerisque, efficitur scelerisque urna pharetra.
					</fieldset>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //services -->
<!-- about -->
	<div class="about">
		<div class="col-md-6 w3_agileits_about_left">
			<div class='bar_group'>
				<div class='bar_group__bar thin elastic' label='donations' value='230'></div>
				<div class='bar_group__bar thin elastic' label='Participations' value='130'></div>
				<div class='bar_group__bar thin elastic' label='Fundraise' value='160'></div>
				<div class='bar_group__bar thin elastic' label='Contribute' value='340'></div>
			</div>
		</div>
		<div class="col-md-6 w3_agileits_about_right">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="agileits_w3layouts_about_right">
								<img src="images/5.png" alt=" " class="img-responsive" />
								<h4>Christina Mark</h4>
								<h5>Volunteer</h5>
								<p>Vivamus euismod, nisi sit amet auctor consequat, tellus metus accumsan tellus,
									sed convallis leo felis feugiat sem.Pellentesque sit amet semper nisl,
									at congue elit ac eros sed nibh ornare iaculis.</p>
							</div>
						</li>
						<li>
							<div class="agileits_w3layouts_about_right">
								<img src="images/7.png" alt=" " class="img-responsive" />
								<h4>Thomas Winston</h4>
								<h5>Volunteer</h5>
								<p>Vivamus euismod, nisi sit amet auctor consequat, tellus metus accumsan tellus,
									sed convallis leo felis feugiat sem.Pellentesque sit amet semper nisl,
									at congue elit ac eros sed nibh ornare iaculis.</p>
							</div>
						</li>
						<li>
							<div class="agileits_w3layouts_about_right">
								<img src="images/6.png" alt=" " class="img-responsive" />
								<h4>Arabella</h4>
								<h5>Volunteer</h5>
								<p>Vivamus euismod, nisi sit amet auctor consequat, tellus metus accumsan tellus,
									sed convallis leo felis feugiat sem.Pellentesque sit amet semper nisl,
									at congue elit ac eros sed nibh ornare iaculis.</p>
							</div>
						</li>
					</ul>
				</div>
			</section>
		</div>
		<div class="clearfix"> </div>
	</div>
<!-- //about -->
<script src="js/bars.js"></script>
<!-- flexSlider -->
	<script defer src="js/jquery.flexslider.js"></script>
	<script type="text/javascript">
		$(window).load(function(){
		  $('.flexslider').flexslider({
			animation: "slide",
			start: function(slider){
			  $('body').removeClass('loading');
			}
		  });
		});
	</script>
<!-- //flexSlider -->
 <div class="clearfix"> </div>  <br>
<!-- mail -->
	
    <style>
.banner{
   min-height:770px;
}
.agileinfo_banner_info{
	margin:13em auto 12em;
	width:60%;
}
    </style>