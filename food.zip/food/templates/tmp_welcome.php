<div id="page-wrapper">
        <div class="col-md-12 graphs"><h3>Welcome <?php echo $sesobj->get('user');?></h3>
	   <div class="col_3">
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-users dollar1 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong><?php echo $tot_task_count;?></strong></h5>
                      <span>Total Customers</span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-th-list icon-rounded"></i>
                    <div class="stats">
                      <h5><strong><?php echo $com_task_count;?></strong></h5>
                      <span>Available Services</span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-thumbs-up user1 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong><?php echo $pen_task_count;?></strong></h5>
                      <span>Today Service</span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-inr user2 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong>Rs. <?php echo $today_task_count;?></strong></h5>
                      <span>Today's Collection</span>
                    </div>
                </div>
        	 </div>
        	<div class="clearfix"> </div>
      </div>
      
      <div class="col_1">
		    <div class="col-md-4 span_7">	
		      <div class="cal1 cal_2"><div class="clndr"><div class="clndr-controls"><div class="clndr-control-button"><p class="clndr-previous-button">previous</p></div><div class="month">July 2015</div><div class="clndr-control-button rightalign"><p class="clndr-next-button">next</p></div></div><table class="clndr-table" border="0" cellspacing="0" cellpadding="0"><thead><tr class="header-days"><td class="header-day">S</td><td class="header-day">M</td><td class="header-day">T</td><td class="header-day">W</td><td class="header-day">T</td><td class="header-day">F</td><td class="header-day">S</td></tr></thead><tbody><tr><td class="day adjacent-month last-month calendar-day-2015-06-28"><div class="day-contents">28</div></td><td class="day adjacent-month last-month calendar-day-2015-06-29"><div class="day-contents">29</div></td><td class="day adjacent-month last-month calendar-day-2015-06-30"><div class="day-contents">30</div></td><td class="day calendar-day-2015-07-01"><div class="day-contents">1</div></td><td class="day calendar-day-2015-07-02"><div class="day-contents">2</div></td><td class="day calendar-day-2015-07-03"><div class="day-contents">3</div></td><td class="day calendar-day-2015-07-04"><div class="day-contents">4</div></td></tr><tr><td class="day calendar-day-2015-07-05"><div class="day-contents">5</div></td><td class="day calendar-day-2015-07-06"><div class="day-contents">6</div></td><td class="day calendar-day-2015-07-07"><div class="day-contents">7</div></td><td class="day calendar-day-2015-07-08"><div class="day-contents">8</div></td><td class="day calendar-day-2015-07-09"><div class="day-contents">9</div></td><td class="day calendar-day-2015-07-10"><div class="day-contents">10</div></td><td class="day calendar-day-2015-07-11"><div class="day-contents">11</div></td></tr><tr><td class="day calendar-day-2015-07-12"><div class="day-contents">12</div></td><td class="day calendar-day-2015-07-13"><div class="day-contents">13</div></td><td class="day calendar-day-2015-07-14"><div class="day-contents">14</div></td><td class="day calendar-day-2015-07-15"><div class="day-contents">15</div></td><td class="day calendar-day-2015-07-16"><div class="day-contents">16</div></td><td class="day calendar-day-2015-07-17"><div class="day-contents">17</div></td><td class="day calendar-day-2015-07-18"><div class="day-contents">18</div></td></tr><tr><td class="day calendar-day-2015-07-19"><div class="day-contents">19</div></td><td class="day calendar-day-2015-07-20"><div class="day-contents">20</div></td><td class="day calendar-day-2015-07-21"><div class="day-contents">21</div></td><td class="day calendar-day-2015-07-22"><div class="day-contents">22</div></td><td class="day calendar-day-2015-07-23"><div class="day-contents">23</div></td><td class="day calendar-day-2015-07-24"><div class="day-contents">24</div></td><td class="day calendar-day-2015-07-25"><div class="day-contents">25</div></td></tr><tr><td class="day calendar-day-2015-07-26"><div class="day-contents">26</div></td><td class="day calendar-day-2015-07-27"><div class="day-contents">27</div></td><td class="day calendar-day-2015-07-28"><div class="day-contents">28</div></td><td class="day calendar-day-2015-07-29"><div class="day-contents">29</div></td><td class="day calendar-day-2015-07-30"><div class="day-contents">30</div></td><td class="day calendar-day-2015-07-31"><div class="day-contents">31</div></td><td class="day adjacent-month next-month calendar-day-2015-08-01"><div class="day-contents">1</div></td></tr></tbody></table></div></div>
		    </div>
            
		    <div class="col-md-8 stats-info"> <br>
       <div class="alert" role="alert" id="msg">
        <strong><?php echo $message ?></strong>
       </div>
                <div class="panel-heading">
                    <h4 class="panel-title">Employee Details</h4>
                </div>
             <div class="panel-body">
                <div class="scrollbar" style="height:285px;" id="style-2">
   <table class="table">
     <thead>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>Employee id</th>
          <th>Phone</th>
          <th>Edit</th>
          <th>delete</th>
        </tr>
      </thead>
      <tbody>
      <?php $i=1; foreach($emp_list as $key => $value) { ?>
        <tr>
          <th scope="row"><?php echo $i;$i=$i+1; ?></th>
          <td><?php echo $emp_list[$key]['name']; ?></td>
          <td><?php echo $emp_list[$key]['emp_id']; ?></td>
          <td><?php echo $emp_list[$key]['phone']; ?></td>
          <td><a href="register.php?id=<?php echo base64_encode(base64_encode($emp_list[$key]['id']));?>"><i class="fa fa-folder-open"></i>Edit</td>
          <td><a href="index.php?task=delete&id=<?php echo base64_encode(base64_encode($emp_list[$key]['id']));?>" onclick="return confirm('Are you sure you want to Remove this Employee?');"><i class="fa fa-trash-o nav_icon"></i></td>
        </tr>
    <?php  } ?>
      </tbody>
    </table>
    </div>
    </div>
            </div>

	  </div> <div class="clearfix"> </div>
    