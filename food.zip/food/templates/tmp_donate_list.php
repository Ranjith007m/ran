     <div class="col-md-12"><br>
<?php if($message1!=null) { ?>
				<br><br><p style="color:red; padding:5px 5px 10px 0px; width:100%;" align="center"><b>&nbsp;<?php echo $message1; ?></b></p>
			<?php $message1='';} ?>
     <div class="panel-body1">
     <div class="scrollbar" style="height:520px;" id="style-2">
   <form action="" method="post"  name="manage_task" id="manage_task" >
   <table class="table">
     <thead>
        <tr>
          <th>#</th>

          <th>Name</th>
          <th>Area</th>
          <th>Mobile</th>
          <th>Type</th>
          <th>For</th>
          <th>Available for</th>
          <th>Transport</th>
          <th>Get by</th>
         <?php if($sesobj->get('orphan_name')=='Admin') echo '<th>Delete</th>'; ?>
        </tr>
      </thead>
      <tbody>
      <?php $i=1; foreach($donar_res as $key => $value) { ?>
        <tr>
          <th><?php echo $i;$i=$i+1; ?></th>
          <th><?php echo $donar_res[$key]['donar_name']; ?></th>
          <th><?php echo $donar_res[$key]['area']; ?></th>
          <th><?php echo $donar_res[$key]['donar_ph']; ?></th>
          <th><?php echo $donar_res[$key]['f_type']; ?></th>
          <th><?php echo $donar_res[$key]['f_for']; ?></th>
          <th><?php echo $donar_res[$key]['f_count']; ?></th>
          <th><?php echo $donar_res[$key]['transport']; ?></th>

          <th><?php if($donar_res[$key]['getby']!='') { echo $donar_res[$key]['getby']; } else { ?><a href="donate_list.php?submit=edit_task&id=<?php echo base64_encode(base64_encode($donar_res[$key]['id']));?>"> <?php echo "I'll Get"; }?></th>
      <?php if($sesobj->get('orphan_name')=='Admin') {?>
        <th><a href="donate_list.php?submit=delete&delete_id=<?php echo base64_encode(base64_encode($donar_res[$key]['id']));?>" onclick="return confirm('Are you sure you want to Remove?');"><i class="fa fa-trash-o nav_icon"></i></th>
       <?php } ?> </tr>

        <?php } ?>

      </tbody>

    </table>
    </form>
    </div>

    </div>   </div>
    <div class="clearfix"> </div>