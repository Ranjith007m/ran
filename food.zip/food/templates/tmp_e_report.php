	<div id="page-wrapper">
        <div class="col-md-12 graphs">
        <div class="xs">
  	 <h3>Employee Performance Report </h3>
     <div class="tab-pane active" id="horizontal-form">
		<form class="form-horizontal" method="post" enctype="multipart/form-data" action="" validate>
        <div class="form-group">
        <div class="col-sm-2">
        <input type="text" value="" required class="form-control1"  name="emp_id" placeholder="Enter Employee ID"  >
        </div>
        <div class="col-sm-2">
        <input type="text" value="" class="form-control1"  name="cus_ph" placeholder="Enter Customer Mobile"  >
        </div>
        <div class="col-sm-3">
        <input type="date" value="" class="form-control1"  name="from_date"  >
        </div>
        <div class="col-sm-3">
        <input type="date" value="" class="form-control1"  name="to_date"  >
        </div>
        <div class="col-sm-2">
        <input type="submit" value="Search" class="btn btn-success warning_2" id="search" name="search">
        </div> </div>
        </form>
        </div>

        <a class="tiles_info col-md-2">
			    <div class="tiles-head red1">
			        <div class="text-center">NAME</div>
			    </div>
			    <div class="tiles-body red"><?php echo stripslashes($emp_res[0]['name']); ?></div>
		</a>

        <a class="tiles_info tiles_blue col-md-2">
			    <div class="tiles-head blue1">
			        <div class="text-center">MOBILE</div>
			    </div>
			    <div class="tiles-body blue1"><?php echo stripslashes($emp_res[0]['phone']); ?></div>
		</a>

        <a class="tiles_info col-md-2">
			    <div class="tiles-head fb1">
			        <div class="text-center">EMP - ID</div>
			    </div>
			    <div class="tiles-body fb2"><?php echo stripslashes($emp_res[0]['emp_id']); ?></div>
		</a>

        <a class="tiles_info col-md-2">
			    <div class="tiles-head tw1">
			        <div class="text-center">D.O.JOINING</div>
			    </div>
			    <div class="tiles-body tw2"><?php echo date("d-m-Y", strtotime($emp_res[0]['doj'])); ?></div>
		</a>

        <a class="tiles_info tiles_blue col-md-2">
			    <div class="tiles-head blue1">
			        <div class="text-center">TOTAL</div>
			    </div>
			    <div class="tiles-body blue1"><i class="fa fa-inr" aria-hidden="true"></i>&nbsp;<?php echo $amount_res[0]['sum(amount)']; ?></div>
		</a>

        <a class="tiles_info col-md-2">
			    <div class="tiles-head red1">
			        <div class="text-center">TO</div>
			    </div>
			    <div class="tiles-body red"><?php echo stripslashes($to_date); ?></div>
		</a>

   <div class="panel-body1">
   <form action="" method="post"  name="manage_task" id="manage_task" >
   <table class="table">
     <thead>
        <tr>
          <th>#</th>
          <th>Date</th>
          <th>Bill No</th>
          <th>CUS - ID</th>
          <th>CUS - MOBILE</th>
          <th>Service</th>
          <th>Tariff</th>
          <!--<th>Discount</th>
          <th>Net Amt</th>-->

        </tr>
      </thead>
      <tbody>
      <?php $i=1; foreach($search_res as $key => $value) { ?>
        <tr>
          <th><?php echo $i;$i=$i+1; ?></th>
          <th><?php echo date("d-m-Y", strtotime($search_res[$key]['b_date'])); ?></th>
          <th><?php echo $search_res[$key]['bill_no']; ?></th>
          <th><?php echo $search_res[$key]['cus_id']; ?></th>
          <th><?php echo $search_res[$key]['cus_ph']; ?></th>
          <th><?php
                $tmp=$search_res[$key]['service'];
                $q="select * from tariff where service_id='$tmp'";
                $name= $sqlobj->getlist($q);
                echo $name[0]['s_name'];
             ?>
          </th>
          <th><i class="fa fa-inr" aria-hidden="true"></i>&nbsp;<?php echo $search_res[$key]['amount']; ?></th>
          <!--<th><?php $tmp=$search_res[$key]['bill_no'];
                $q="select * from amount where b_no='$tmp'";
                $name= $sqlobj->getlist($q);
                echo $name[0]['discount']; ?></th>
          <th><?php echo $search_res[$key]['bill_no']; ?></th>-->
        </tr>

        <?php } ?>

      </tbody>

    </table>
    </form>
    </div>

  </div>

