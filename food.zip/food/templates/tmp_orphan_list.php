<div class="events" id="events">
		<div class="container">
			<h3 class="agileinfo_header w3layouts_header">Orphanage<span>Lists</span></h3>
			<p class="w3_services_para"><span>Here you can find orphanage lists</span></p>
			<div class="w3_agile_services_grids">
                <?php foreach($search_res as $key => $value) { ?>
				<div class="col-md-4 w3_agileits_events_grid">
					<div class="wthree_events_grid">
						<div class="wthree_events_grid1">
							<img src="images/7.jpg" alt=" " class="img-responsive" />
							<div class="agileits_event_grid_date">
								<p><span><?php echo $search_res[$key]['orphan_count']; ?> PEOPLE NEED&nbsp; HELP</span>Rs. <?php echo $search_res[$key]['orphan_cost']; ?> / Day
                                <?php if($sesobj->get('orphan_name')=='Admin') {?>
                                <h3 style="float:right;"><a href="orphan_list.php?task=delete&delete_id=<?php echo base64_encode(base64_encode($search_res[$key]['id']));?>" onclick="return confirm('Are you sure you want to Remove?');"><i class="fa fa-trash-o nav_icon"></i>Delete</h3>
                                <?php } ?>
                                </p>
							</div>
						</div>
						<div class="agileinfo_events_grid1">
							<h5><a href="#" data-toggle="modal" data-target="#myModal"><?php echo $search_res[$key]['orphan_name']; ?></a></h5>
                            <ul>
                            <li>Contact : <?php echo $search_res[$key]['orphan_person']; ?></li>
                            <li>Mobile : <?php echo $search_res[$key]['orphan_ph']; ?></li>
                            <li>Area : <?php echo $search_res[$key]['area']; ?></li>
                            <li>Visit : <?php echo $search_res[$key]['orphan_web']; ?></li>
                            <li>Mail to : <?php echo $search_res[$key]['orphan_email']; ?></li>
                            </ul>
							<p><?php echo $search_res[$key]['orphan_msg']; ?></p>
						</div>
					</div>
				</div>
              <?php $t=$key+1; if ($t%3==0) echo '<div class="clearfix"></div> '; } ?>
				<div class="clearfix"> </div>
			</div>

		</div>
	</div>