<!-- banner -->
	<div class="banner">
		<div class="container">
			<div class="w3_agile_header">
				<div class="w3_agile_header_left">
					<h2>Call us for help <span>+(000) 123 456 78</span></h2>
				</div>
				<div class="agile_logo">
					<h1><a href="index.php"><span>Orphanage</span> Home</a></h1>
				</div>
				<div class="agileits_w3layouts_mail">
					<p><i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:info@example.com">info@example.com</a></p>
				</div>
				<div class="clearfix"> </div>
				<div class="w3_agileits_nav">
					<nav class="wthree_nav_menu">
						<ul>
							<li><a href="#" class="icon icon-menu" id="btn-menu">Menu</a></li>
						</ul>
					</nav>
					<div id="sideNav">
						<ul>
                        	<li><a href="index.php" class="w3_home"><span>Home</span></a></li>
                        <?php if($page=='index') { ?>
                        <li><a href="#about" class="scroll w3_about"><span>About</span></a></li>
						<li><a href="#services" class="scroll w3_services"><span>Services</span></a></li>

                        <?php } ?>
							<li><a href="donar.php" class="fa-heart"><span>Donate Food</span></a></li>
							<li><a href="orphan_list.php" class="fa-group"><span>Orphange</span></a></li>
                           <?php if ($sesobj->isassign('orphan_name'))
                            { ?>
                           <li><a href="donate_list.php" class="w3_services"><span>Offer List</span></a></li>

                        <?php } ?>
							<li><a href="admin.php" class=" w3_work"><span>Admin</span></a></li>
							<li><a href="register.php" class="w3_mail"><span>Register</span></a></li>
                            <li><a href="login.php" class="fa-sign-in"><span>Login</span></a></li>
                             <li><a href="logout.php" class="fa-power-off"><span>Logout</span></a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="agileinfo_banner_info">
				<h3><span>we rise by</span> lifting others</h3>
			</div>

		</div>
	</div>
<!-- //banner -->