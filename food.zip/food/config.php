<?PHP

	/** Database server configuration */
	define("_HOSTNAME", "localhost");
	define("_USERNAME", "root");
	define("_PASSWORD", "");
	define("_DATABASE", "food");
	
	//unset($_SESSION['REMOTE_ADDR']);
	
	/*
	function get_ip() {
//Just get the headers if we can or else use the SERVER global
if ( function_exists( 'apache_request_headers' ) ) {
$headers = apache_request_headers();
} else {
$headers = $_SERVER;
}
//Get the forwarded IP if it exists
if ( array_key_exists( 'X-Forwarded-For', $headers ) && filter_var( $headers['X-Forwarded-For'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
$the_ip = $headers['X-Forwarded-For'];
} elseif ( array_key_exists( 'HTTP_X_FORWARDED_FOR', $headers ) && filter_var( $headers['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 )
) {
$the_ip = $headers['HTTP_X_FORWARDED_FOR'];
} else {
$the_ip = filter_var( $_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 );
}
return $the_ip;
} */

	function createRandomVal($val){
      $chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789,-";
      srand((double)microtime()*1000000);
      $i = 0;
      $pass = '' ;
      while ($i<=$val) 
    {
        $num  = rand() % 33;
        $tmp  = substr($chars, $num, 1);
        $pass = $pass . $tmp;
        $i++;
      }
    return $pass;
    }
    
	$ip=createRandomVal(7);
	
	if(!isset($_SESSION["REMOTE_ADDR"])) { $_SESSION["REMOTE_ADDR"] =$ip; } else { /*Do nothing since the session already exist man*/ } 

	/** Path to code */
	define("_PATH_CODE", "code/code_");
	
	/** Path to include files */
	define("_PATH_INCLUDE", "include/");

	/** Path to JavaScript files */
	define("_PATH_JAVASCRIPT", "js/");
	
	/** Path to templates root */
	define("_PATH_TEMPLATE", "templates/tmp_");

	/** Path to cascading style sheet */
	define("_PATH_STYLESHEET", "css/");	

	/** Path to images */
	define("_PATH_IMAGES", "images/front/");

	/** Application Title */

	define("_APP_TITLE", "Wastage Food Proccessing System");
	define("_APP_SUB_TITLE", "");

	/** Set self url */
	define("_SELF_URL", basename($_SERVER['PHP_SELF']));

	/** Set site url */
	define("_SITE_URL", $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF']);

	/** Set request url */
	define("_REQUEST_URL", $_SERVER['REQUEST_URI']);

	/** Error Message **/
	define("_TMPFILE_ERROR", "<font color='red'>Template File Not Found</font>");
	define("_CODEFILE_ERROR", "<font color='red'>Code File Not Found</font>");
	error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
    //date_default_timezone_get();
    date_default_timezone_set('Asia/Kolkata');
?>